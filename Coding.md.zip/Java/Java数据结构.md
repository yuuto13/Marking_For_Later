# Java数据结构

## HashMap底层数据结构详解

* **JDK1.7及之前：数组+链表**
* **JDK1.8：数组+链表+红黑树**

基础特性：数组的长度必须是2的指数次幂（空参的HashMap初始容量是16），HashMap的加载因子默认设置为0.75，链表长度大于等于8时会转成红黑树。

##### 为什么数组的长度必须是2的指数次幂

HashMap添加元素时索引的下标可以通过取模运算获得，但是我们知道计算机的运行效率：加法(减法)>乘法>除法>取模，取模的效率是最低的，而且HashMap扩容要进行数组的移动，每移动一次就要重回记算索引，这个过程中牵扯大量元素的迁移和取模运算，会大大影响效率。而HashMap底层使用**与运算**​`(length - 1) & hash`​取代**取模运算**​`hash % length`​，大大提升了计算的效率，但是只有在length为2的整数次幂时，这两种方式计算出来的结果才是一致的，因此HashMap中数组的长度必须是2的指数次幂。

##### 为什么默认加载因子是0.75

加载因子如果定的太大，比如1，就意味着数组的每个空位都需要填满，达到理想状态，不产生链表，但实际是不可能达到这种理想状态。如果一直等数组填满才扩容，虽然达到了最大的数组空间利用率，但会产生大量的哈希碰撞，同时产生更多的链表，降低了查询效率。

如果设置的过小，比如0.5，虽然保证了数组空间很充足，减少了哈希碰撞，查询效率很高，但却消耗了大量空间。

因此，我们就需要在时间和空间上做一个折中，选择最合适的负载因子以保证最优化，取到了0.75。

##### 为什么链表长度大于等于8时会转成红黑树

‍

##### HashMap put方法

​![image](assets/image-20230921153847-px7k3js.png)​

​![image](assets/image-20230921153855-cm9n2vm.png)​

```java
    /**
     * Implements Map.put and related methods
     *
     * @param hash hash for key
     * @param key the key
     * @param value the value to put
     * @param onlyIfAbsent if true, don't change existing value
     * @param evict if false, the table is in creation mode.
     * @return previous value, or null if none
     */
	final V putVal(int hash, K key, V value, boolean onlyIfAbsent, boolean evict) {
        Node<K,V>[] tab;
		Node<K,V> p;
		int n, i;
        //1. 如果当前table为空，新建默认大小的table
        if ((tab = table) == null || (n = tab.length) == 0)
            n = (tab = resize()).length;
        //2. 获取当前key对应的节点
        if ((p = tab[i = (n - 1) & hash]) == null)
            //3. 如果不存在，新建节点
            tab[i] = newNode(hash, key, value, null);
        else {
            //4. 存在节点
            Node<K,V> e; K k;
            //5. key的hash相同，key的引用相同或者key equals，则覆盖
            if (p.hash == hash && ((k = p.key) == key || (key != null && key.equals(k))))
                e = p;
            //6. 如果当前节点是一个红黑树树节点，则添加树节点
            else if (p instanceof TreeNode)
                e = ((TreeNode<K,V>)p).putTreeVal(this, tab, hash, key, value);
            //7. 不是红黑树节点，也不是相同节点，则表示为链表结构
            else {
                for (int binCount = 0; ; ++binCount) {
                    //8. 找到最后那个节点
                    if ((e = p.next) == null) {
                        p.next = newNode(hash, key, value, null);
                        //9. 如果链表长度超过8转成红黑树
                        if (binCount >= TREEIFY_THRESHOLD - 1) // -1 for 1st
                            treeifyBin(tab, hash);
                        break;
                    }
                    //10.如果链表中有相同的节点，则覆盖
                    if (e.hash == hash &&
                        ((k = e.key) == key || (key != null && key.equals(k))))
                        break;
                    p = e;
                }
            }
            if (e != null) { // existing mapping for key
                V oldValue = e.value;
                //是否替换掉value值
                if (!onlyIfAbsent || oldValue == null)
                    e.value = value;
                afterNodeAccess(e);
                return oldValue;
            }
        }
        //记录修改次数
        ++modCount;
        //是否超过容量，超过需要扩容
        if (++size > threshold)
            resize();
        afterNodeInsertion(evict);
        return null;
    }
```

## TreeMap和TreeSet

TreeMap和TreeSet和普通的HashMap不一样，普通的HashMap元素存取的时间复杂度一般是O(1)的范围。而TreeMap是通过红黑树实现的，内部对元素的操作复杂度为O(logn)。虽然在元素的存取方面TreeMap并不占优，但是它内部的元素都是排序的，当需要查找某些元素以及顺序输出元素的时候它能够带来比较理想的结果。可以说，TreeMap是一个内部元素排序版的HashMap。

#### TreeMap和TreeSet之间的关系

TreeSet是通过封装了一个TreeMap的成员变量来实现的，因此跟HashSet和HashMap的关系一样，TreeSet只是TreeMap的一个马甲。

‍
